<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My PHP file</title>
</head>
<body>
    <h1>Introduction</h1>
    <p><?php 
        if(isset($_GET['err'])){
            echo $_GET['err'];
        }
    ?></p>
    <form action="test.php" method="post">
        <input type="text" name="uname">
        <input type="password" name="pass">
        <input type="submit" value="SignUp">
    </form>

</body>
</html>
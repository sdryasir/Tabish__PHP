<?php
    $uname =  $_POST['uname'];
    $pass =  $_POST['pass'];

    login($uname, $pass);

    function login($user, $password)
    {
        if($user == 'yasir' && $password=='123')
        {
            echo "You are logged in";
        }else{
            header('Location: index.php?err=incorrect password or username');
        }
    }
?>